export default function komputerPilih() {
    const pilihan = ['batu', 'gunting', 'kertas'];
    const randomIndex = Math.floor(Math.random() * pilihan.length);
    return pilihan[randomIndex];
}
