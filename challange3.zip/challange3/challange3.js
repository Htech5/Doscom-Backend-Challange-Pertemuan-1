import komputerPilih from './RANDOMPC/komputerPilih.js'

const pilihanPlayer = 'batu'
const pilihanKomputer = komputerPilih()

function tentukanPemenang(pilihanPlayer, pilihanKomputer) {
    switch (pilihanPlayer) {
        case 'batu':
            if (pilihanKomputer === 'gunting') {
                console.log("Player choice: batu, Comp choice: gunting, Output: menang")
            } else if (pilihanKomputer === 'kertas') {
                console.log("Player choice: batu, Comp choice: kertas, Output: kalah")
            } else {
                console.log("Player choice: batu, Comp choice: batu, Output: seri")
            }
            break

        case 'gunting':
            if (pilihanKomputer === 'batu') {
                console.log("Player choice: gunting, Comp choice: batu, Output: kalah")
            } else if (pilihanKomputer === 'kertas') {
                console.log("Player choice: gunting, Comp choice: kertas, Output: menang")
            } else {
                console.log("Player choice: gunting, Comp choice: gunting, Output: seri")
            }
            break

        case 'kertas':
            if (pilihanKomputer === 'batu') {
                console.log("Player choice: kertas, Comp choice: batu, Output: menang")
            } else if (pilihanKomputer === 'gunting') {
                console.log("Player choice: kertas, Comp choice: gunting, Output: kalah")
            } else {
                console.log("Player choice: kertas, Comp choice: kertas, Output: seri")
            }
            break

        default:
            console.log("Pilihan tidak valid.")
    }
}

tentukanPemenang(pilihanPlayer, pilihanKomputer)
