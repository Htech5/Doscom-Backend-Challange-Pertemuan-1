const lingkaran = require('./kelilingBangunDatar/lingkaran.js')
const persegi = require('./kelilingBangunDatar/persegi.js')
const persegiPanjang = require('./kelilingBangunDatar/persegiPanjang.js')
const segitiga = require('./kelilingBangunDatar/segitiga.js')
const readline = require('readline')

const inputPengguna = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function cumanBuatOpening() {
    console.log("===========================================")
    console.log("Masukkan bangun datar yang akan dihitung : ")
    console.log("1. Segitiga 2. Persegi Panjang 3. Persegi 4. Lingkaran 5. Keluar")
}

function prosesPilihan() {
    console.log("===========================================")
    inputPengguna.question('Pilih opsi (1-5): ', (opsi) => {
        opsi = parseInt(opsi)

        switch (opsi) {
            case 1:
                console.log("===SEGITIGA===")
                inputPengguna.question('Masukkan sisi A = ', (sisiA) => {
                    console.log("==========")
                    inputPengguna.question('Masukkan sisi B = ', (sisiB) => {
                        console.log("==========")
                        inputPengguna.question('Masukkan sisi C = ', (sisiC) =>{
                            console.log("==========")
                            console.log(`sisi A = ${sisiA} `)
                            console.log(`sisi B = ${sisiB}`)
                            console.log(`sisi C = ${sisiC}`)
                            console.log(`Keliling = ${segitiga(parseFloat(sisiA), parseFloat(sisiB), parseFloat(sisiC))}`)
                            lanjutkan();
                        })
                    });
                });
                break
            case 2:
                console.log("===PERSEGI PANJANG===")
                inputPengguna.question('Masukkan panjang = ', (panjang) => {
                    console.log("==========")
                    inputPengguna.question('Masukkan lebar = ', (lebar) => {
                        console.log("==========")
                        console.log(`Lebar = ${lebar}`)
                        console.log(`Panjang = ${panjang}`)
                        console.log(`Keliling = ${persegiPanjang(parseFloat(panjang), parseFloat(lebar))}`)
                        lanjutkan()
                    });
                });
                break
            case 3:
                console.log("===PERSEGI===")
                inputPengguna.question('Masukkan sisi = ', (sisi) => {
                    console.log("==========")
                    console.log(`Sisi = ${sisi}`)
                    console.log(`Keliling = ${persegi(parseFloat(sisi))}`)
                    lanjutkan();
                });
                break
            case 4:
                console.log("===LINGKARAN===")
                inputPengguna.question('Masukkan jari-jari = ', (jariJari) => {
                    console.log("==========")
                    console.log(`Jari-jari = ${jariJari}`)
                    console.log(`Keliling = ${lingkaran(parseFloat(jariJari))}`)
                    lanjutkan();
                });
                break;
            case 5:
                console.log("Terima kasih! Program selesai.")
                inputPengguna.close()
                return
            default:
                console.log("Opsi tidak valid. Silakan pilih angka antara 1 dan 5.")
                console.log("==========")
                lanjutkan()
        }
    });
}

function lanjutkan() {
    cumanBuatOpening()
    prosesPilihan()
}

lanjutkan()
