function persegi(s){
    return s*4
}

module.exports = persegi