function segitiga(sisiA, sisiB, sisiC) {
    return sisiA + sisiB + sisiC
}

module.exports = segitiga