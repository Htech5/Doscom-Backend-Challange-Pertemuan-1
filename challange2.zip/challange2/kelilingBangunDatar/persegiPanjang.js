function persegiPanjang(p,l){
    return 2 * (p+l)
}

module.exports = persegiPanjang