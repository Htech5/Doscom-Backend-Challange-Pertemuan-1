const phi = 3.14

function lingkaran(r){
    return phi * r * 2
}

module.exports = lingkaran